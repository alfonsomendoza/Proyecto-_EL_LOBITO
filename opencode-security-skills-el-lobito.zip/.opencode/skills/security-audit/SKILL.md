---
name: security-audit
description: Run a read-only, evidence-based audit of Laravel routes, roles, data access, configuration, uploads, imports, and web risks.
compatibility: opencode
metadata:
  project: el-lobito
  opencode/slash: "true"
---
# Auditoría de seguridad (solo lectura primero)
Por defecto inspecciona sin editar, instalar paquetes ni ejecutar acciones que cambien datos. Pide autorización para escaneo activo, fuzzing, explotación o pruebas contra hosts externos.
## Inspecciona
- Git status, rama y commit sin cambiar rama/historial.
- composer.json/lock, rutas, controladores, middleware/policies, validación, Blade, config, migraciones, tests, Docker, CI y .gitignore. No imprimas `.env`.
- Autenticación/autorización del lado servidor; IDOR/BOLA; privilegios; mass assignment; SQL/command injection; XSS; CSRF; SSRF; redirecciones; subida/importación de archivos; path traversal; límites de tasa; sesiones/cookies; CORS/CSP/headers; errores; logs; backups expuestos; debug y dependencias vulnerables.
- Sigue las acciones de caja, ventas, anulación, cierre, propinas, división/traslado de cuentas e inventario desde ruta hasta transacción, auditoría y prueba.
## Seguridad de ejecución
- Confirma la conexión de DB antes de ejecutar tests. Usa SQLite aislado o una base desechable con datos sintéticos.
- Nunca uses producción para tests. No ejecutes migrate:fresh, db:wipe, rollback destructivo ni escaneos agresivos.
## Cada hallazgo
ID, severidad, archivo/ruta/evidencia, precondiciones, impacto, reproducción segura, fix mínimo, prueba de regresión, referencia OWASP/ASVS sin inventar cláusulas y riesgo residual. No llames confirmado a un supuesto. Termina con tests ejecutados, omitidos y plan priorizado.
