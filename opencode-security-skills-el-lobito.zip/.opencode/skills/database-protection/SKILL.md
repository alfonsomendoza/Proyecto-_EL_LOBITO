---
name: database-protection
description: Protect database migrations, backups, credentials, transactions, least privilege, and MySQL/PostgreSQL portability.
compatibility: opencode
metadata:
  project: el-lobito
  opencode/slash: "true"
---
# Protección de base de datos
## Prohibiciones
No conectar a producción sin autorización explícita. No ejecutar DROP/TRUNCATE, borrados no revisados, db:wipe, migrate:fresh o rollback destructivo en producción. No imprimir ni publicar dumps, `.env` o datos reales.
Antes de una migración aprobada: confirmar destino, inspeccionar esquema/historial, hacer backup reciente, probar restore aislado, revisar locks/downtime y preparar rollback/forward-fix.
Una migración cuyo `up()` omite crear una tabla existente no debe borrarla en `down()`.
## Controles
- Cuentas separadas y de mínimo privilegio para runtime, migraciones y backups.
- No exponer DB a Internet; red privada y TLS cuando corresponda.
- Prepared statements, constraints, índices basados en consultas reales, transacciones acotadas y orden de locks consistente.
- Idempotencia/constraints para evitar duplicados y carreras; auditoría de cambios financieros.
- Cifrar backups en tránsito/reposo, restringir acceso/retención y probar restauración periódicamente.
- Preferir cambios aditivos expand/contract y separar cambios de esquema/backfill.
## Portabilidad
No asumir equivalencia entre MySQL y PostgreSQL: revisar SQL raw, JSON, collation, fechas, tipos unsigned/enum, autoincrement, locks, funciones y sintaxis específica. Probar con ambos motores reales en bases desechables; SQLite no prueba portabilidad.
## Revisión de migración
Leer migración e historial; comprobar existencia previa y comportamiento de `down()`, datos, defaults/nulls, claves, locks y repetibilidad. Probar solo en DB desechable con datos sintéticos y reportar incertidumbres.
