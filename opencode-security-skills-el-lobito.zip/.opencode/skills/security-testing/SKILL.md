---
name: security-testing
description: Plan authorized security regression tests for Laravel authentication, roles, imports, APIs, sessions, and business logic.
compatibility: opencode
metadata:
  testing: security
  opencode/slash: "true"
---
# Pruebas de seguridad
Usa entorno local aislado y datos sintéticos. Pide autorización para fuzzing, brute force, escaneos activos, explotación, carga o cualquier test en staging/producción. Confirma DB destino antes de ejecutar; nunca uses producción.
## Categorías
- Autenticación, sesión, throttling, reset de contraseña.
- Autorización por rol, acceso directo a endpoints, IDOR/BOLA y acceso cruzado.
- SQLi, XSS, CSRF, mass assignment, path traversal, uploads, CSV formula injection y payloads grandes.
- Lógica: manipulación de precio/cantidad, replay/doble envío, concurrencia, caja, facturas/anulaciones, atribución de propinas, transferencias/división de cuentas e inventario negativo/importaciones duplicadas.
- Configuración: errores, headers, cookies, CORS, rate limits, backups expuestos y TLS.
- Fallos parciales, rollback transaccional, idempotencia y auditoría.
Por cada acción, prueba actor permitido, roles denegados, ID/campos manipulados, ausencia de cambios parciales y conservación de históricos. No inventes columnas. SQLite verde no demuestra compatibilidad MySQL/PostgreSQL.
Reporta comandos exactos, entorno/DB, resultados, pruebas omitidas y limitaciones. Nunca afirmes que la aplicación es segura solo porque tests pasan.
