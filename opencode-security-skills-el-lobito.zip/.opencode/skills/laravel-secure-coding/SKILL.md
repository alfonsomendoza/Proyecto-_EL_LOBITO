---
name: laravel-secure-coding
description: Apply secure Laravel patterns and authorization tests without breaking El Lobito business rules or production data.
compatibility: opencode
metadata:
  framework: laravel
  opencode/slash: "true"
---
# Laravel seguro
## Antes de editar
Confirma versión real de Laravel/PHP, autenticación, rutas, roles, esquema y patrones de tests. No inventes columnas/modelos ni cambies arquitectura por preferencia.
## Controles
- Autorización en servidor en cada endpoint; validar rol y propiedad/relación del registro. Ocultar botones no es seguridad.
- Validación allow-list, Form Requests cuando encajen, protección mass assignment y consultas parametrizadas.
- Blade `{{ }}` por defecto; evita `{!! !!}` salvo contenido confiable sanitizado para su contexto.
- Mantén CSRF, throttling de login/acciones sensibles, regeneración de sesión, cookies seguras y políticas de sesión apropiadas.
- Validar imports/uploads por tamaño, MIME, extensión, contenido, encoding y número de filas; nombre generado por servidor; prevenir CSV formula injection.
- Transacciones, locks/idempotencia y restricciones para operaciones concurrentes de dinero/inventario.
- No exponer stack traces, SQL, secretos ni datos personales en respuestas/logs. No registrar contraseñas, tokens o datos completos de tarjetas.
- APP_DEBUG=false, APP_KEY única, HTTPS y proxies confiables correctamente configurados en producción.
## Reglas El Lobito
- No borrar ni reescribir ventas, facturas, propinas, caja, cuentas o movimientos históricos.
- Mantener separados estados financieros y estados de cocina.
- No ampliar privilegios ni asumir propiedad por tener un rol permitido.
- No modificar esquema ni migrar MySQL real sin autorización específica, respaldo verificado y revisión de impacto.
## Pruebas mínimas
No autenticado, roles permitidos/denegados, ID manipulado, acceso cruzado, campos tamperados y rollback ante fallo. Para dinero/inventario, probar reintentos y concurrencia. Explica cambios, amenaza mitigada, tests ejecutados/omitidos y riesgos restantes.
