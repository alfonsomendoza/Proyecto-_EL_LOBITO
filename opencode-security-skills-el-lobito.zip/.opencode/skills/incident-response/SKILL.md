---
name: incident-response
description: Respond safely to suspected compromise, leaked credentials, ransomware, unauthorized access, or data exposure affecting El Lobito.
compatibility: opencode
metadata:
  security-operations: incident-response
  opencode/slash: "true"
---
# Respuesta a incidentes
1. Establece hechos, activos afectados, línea temporal y responsable autorizado.
2. Preserva evidencia (logs, timestamps, alertas, commit IDs); no borres evidencia.
3. Contén con plan aprobado: restringe acceso/red o deshabilita credenciales comprometidas. No borres hosts, contenedores, volúmenes ni logs como primera acción.
4. Si una clave se expuso, revócala/rotala con el proveedor; quitarla del archivo/Git no basta.
5. Protege operaciones y registros históricos de ventas, caja, facturas, propinas e inventario.
6. Evalúa alcance y datos afectados; consulta hosting, proveedor de pagos, asesoría legal/privacidad y autoridades cuando corresponda.
7. Recupera de imágenes/backups confiables solo después de revisar vector de entrada; corrige causa y monitorea recurrencia.
No publiques logs, datos de clientes, credenciales ni detalles explotables. No des por sentadas obligaciones legales/plazos sin verificar la ley aplicable con asesoría.
Registra ID, tiempos/zona horaria, hechos vs hipótesis, activos, acciones/aprobaciones, evidencia, alcance, contención, recuperación, comunicaciones y lecciones. Mapea la respuesta a NIST CSF Respond/Recover y al proceso de riesgos ISO; no afirmes certificación.
