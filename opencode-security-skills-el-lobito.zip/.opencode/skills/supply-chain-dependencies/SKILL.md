---
name: supply-chain-dependencies
description: Audit Composer, npm, GitHub Actions, base images, secrets, and dependency updates safely.
compatibility: opencode
metadata:
  project: el-lobito
  opencode/slash: "true"
---
# Seguridad de cadena de suministro
- Inspecciona composer.json/lock, package manifests/lockfiles, workflows, Docker bases y releases.
- No instales/actualices/elimines dependencias ni cambies lockfiles sin autorización.
- Prefiere auditorías de solo lectura (`composer audit --locked` si disponible), alertas GitHub y escáneres autorizados. No imprimas tokens/URLs privadas.
- Usa lockfiles y builds reproducibles; investiga advisory, versiones afectadas, explotabilidad, reachability y fix disponible.
- Haz actualizaciones pequeñas y dirigidas; revisa changelog y tests. No hagas update masivo como primera respuesta.
- Habilita Dependabot, secret scanning, push protection, branch protection y permisos mínimos de CI según política.
- En GitHub Actions fija acciones a SHA revisados para mayor garantía; no expongas secretos a código no confiable de PR.
- Si un secreto fue comprometido, revócalo/rotalo: borrar el texto no invalida la credencial.
- No versionar `.env`, SQL dumps, claves privadas, datos de clientes, `node_modules` ni artefactos salvo política explícita.
Reporta paquete/versión/advisory, riesgo realista, fix mínimo, incompatibilidades, tests y riesgo pendiente. La auditoría es una instantánea, no monitoreo permanente.
