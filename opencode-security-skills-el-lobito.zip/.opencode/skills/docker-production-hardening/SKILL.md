---
name: docker-production-hardening
description: Harden Dockerfiles, Compose, containers, secrets, networks, and deployment for El Lobito.
compatibility: opencode
metadata:
  deployment: docker
  opencode/slash: "true"
---
# Docker seguro
- Inspecciona archivos existentes antes de editar; no los sobrescribas a ciegas.
- `.dockerignore` debe excluir `.env`, claves, dumps SQL, `.git`, `vendor`, `node_modules` y datos locales según el build.
- Usa imágenes/versiones mantenidas y fijadas deliberadamente; valida PHP y extensiones contra composer.lock.
- Ejecuta como usuario no-root; evita privileged, host networking y montaje de Docker socket; elimina capabilities innecesarias, activa no-new-privileges, límites y healthchecks.
- Publica solo el puerto web necesario; DB/cache en red interna, nunca expuestas públicamente por defecto.
- Secretos vía secret store; nunca en imágenes, build args, Compose commiteado o logs.
- Producción: APP_DEBUG=false, HTTPS, proxy confiable, headers, límites de upload, logs rotados, actualizaciones, SBOM/escaneo de imagen cuando sea posible.
- Usa volúmenes persistentes y plan de backup/restore. `docker compose down -v` puede borrar volúmenes: no lo recomiendes casualmente.
- No ejecutes migraciones automáticamente al arrancar contra DB desconocida.
- Nunca conectes el contenedor de desarrollo a `sistemadecaja` real por defecto.
Distingue Docker local de producción; un contenedor que construye/arranca no está automáticamente seguro. Antes de release confirma TLS, secretos, firewall, backup restaurable, logs, smoke tests y rollback.
