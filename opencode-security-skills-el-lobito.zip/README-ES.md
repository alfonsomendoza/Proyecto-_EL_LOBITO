# OpenCode Security Skills — El Lobito

Paquete de ocho skills para guiar a OpenCode en revisiones de seguridad de un proyecto Laravel. Son instrucciones para el agente; no son un antivirus, firewall, pentest certificado ni garantía de que el sitio quede protegido.

## Contenido
- security-governance
- security-audit
- laravel-secure-coding
- database-protection
- docker-production-hardening
- supply-chain-dependencies
- security-testing
- incident-response

## Instalación en el repositorio
1. Haz copia/asegura un estado Git recuperable.
2. Extrae el ZIP en una carpeta temporal.
3. Copia `.opencode/skills/` a la raíz del repo El Lobito conservando la estructura.
4. Revisa `git status --short`; no uses `git add .` automáticamente.
5. Abre una sesión nueva de OpenCode.
6. Prueba con: `@security-audit Realiza una auditoría de solo lectura. No edites archivos ni conectes a producción.`

## Instalación global alternativa
Copia cada carpeta a `%USERPROFILE%\.config\opencode\skills\<nombre>\SKILL.md`. Para reglas específicas del proyecto se recomienda la instalación local.

## Marcos de referencia
- ISO/IEC 27001:2022; ISO/IEC 27002:2022; ISO/IEC 27005.
- NIST Cybersecurity Framework 2.0 y NIST SP 800-218 SSDF.
- OWASP Top 10:2025; OWASP ASVS 5.0.0; OWASP Cheat Sheet Series; OWASP API Security Top 10 cuando aplique.
- CIS Controls v8.1.
- PCI DSS 4.0.1 solo si el entorno procesa/almacena/transmite datos de tarjetas. No almacenar PAN/CVV.

Fuentes:
- OpenCode: https://docs.opencode.ai/docs/skills/
- ISO: https://www.iso.org/standard/27001
- NIST CSF: https://www.nist.gov/cyberframework
- NIST SSDF: https://csrc.nist.gov/pubs/sp/800/218/final
- OWASP Top 10: https://owasp.org/www-project-top-ten/
- OWASP ASVS: https://asvs.owasp.org/
- CIS Controls: https://www.cisecurity.org/controls
- PCI SSC: https://www.pcisecuritystandards.org/

## Límites importantes
Las skills no aplican controles automáticamente. También se necesitan configuración segura del servidor, HTTPS, firewall, actualizaciones, gestión de secretos, backups restaurables, monitoreo y pruebas humanas. No garantizan cumplimiento legal, ISO o PCI. No hagas pruebas activas contra producción sin autorización y alcance. No ejecutes migraciones contra MySQL real ni `migrate:fresh`, `db:wipe`, rollback destructivo o `docker compose down -v` sin autorización, plan de recuperación y entorno confirmado. Mantén `.env`, credenciales, claves, dumps SQL y datos reales fuera de Git y del contexto Docker.
